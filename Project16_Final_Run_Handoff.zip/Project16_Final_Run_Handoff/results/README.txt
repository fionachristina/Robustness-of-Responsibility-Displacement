Project 16 analysis outputs

RQ1: rq1_model_robustness.csv; figure1_rq1_robustness.(png/pdf)
RQ2: rq2_actor_responsibility.csv; figure2_rq2_actor_attribution.(png/pdf)
RQ3: rq3_dilemma_effects.csv; figure3_rq3_dilemma_effects.(png/pdf)
RQ4: rq4_mediation_sensitivity.csv; figure4_rq4_mediation_sensitivity.(png/pdf)
data_audit.csv: analytic sample and outcome reconciliation.

The supplied SPSS files contain final analytic samples only; participant-screening sensitivity cannot be assessed for excluded cases. Indirect-path estimates are assumption-dependent and not causal mediation effects. Confirm reuse terms before redistribution/publication.

Caution: Some local negative-binomial bootstrap resamples emitted optimizer convergence warnings. The RQ4 intervals are exploratory; audit model convergence and rerun before making manuscript-level claims.
